@echo off
chcp 65001 >nul
title Otimizador Windows 11 - Johnny_Gedulin
mode con: cols=95 lines=38
color 0B

:: Verificar privilégios de Administrador
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo ==============================================================================
    echo   AVISO: Este script precisa ser executado como Administrador.
    echo   Tentando elevar privilegios automaticamente...
    echo ==============================================================================
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

:MENU
cls
echo =========================================================================================
echo   ██████╗ ████████╗██╗███╗   ███╗██╗███████╗ █████╗ ██████╗  ██████╗ ██████╗ 
echo  ██╔═══██╗╚══██╔══╝██║████╗ ████║██║╚══███╔╝██╔══██╗██╔══██╗██╔═══██╗██╔══██╗
echo  ██║   ██║   ██║   ██║██╔████╔██║██║  ███╔╝ ███████║██║  ██║██║   ██║██████╔╝
echo  ██║   ██║   ██║   ██║██║╚██╔╝██║██║ ███╔╝  ██╔══██║██║  ██║██║   ██║██╔══██╗
echo  ╚██████╔╝   ██║   ██║██║ ╚═╝ ██║██║███████╗██║  ██║██████╔╝╚██████╔╝██║  ██║
echo   ╚═════╝    ╚═╝   ╚═╝╚═╝     ╚═╝╚═╝╚══════╝╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝
echo =========================================================================================
echo   SISTEMA DE OTIMIZACAO EXCLUSIVO PARA WINDOWS 11
echo   Criado por Johnny_Gedulin
echo =========================================================================================
echo.
echo   [1] Executar Otimizacao Completa Automatica (Altamente Recomendado)
echo   [2] Categoria: Limpeza e Otimizacao de Discos
echo   [3] Categoria: Rede e Compartilhamento (Impressoras)
echo   [4] Categoria: Sistema, Reparos e Atualizacoes
echo   [5] Sair
echo.
echo =========================================================================================
set /p opcao="Escolha uma categoria principal (1-5): "

if "%opcao%"=="1" goto COMPLETA
if "%opcao%"=="2" goto MENU_LIMPEZA
if "%opcao%"=="3" goto MENU_REDE
if "%opcao%"=="4" goto MENU_SISTEMA
if "%opcao%"=="5" exit
goto MENU

:MENU_LIMPEZA
cls
echo =========================================================================================
echo   CATEGORIA: LIMPEZA E DISCOS
echo =========================================================================================
echo.
echo   [1] Limpeza de Arquivos Temporarios e Cache de Sistema
echo   [2] Otimizacao de Discos e Ativacao de Alto Desempenho (TRIM / Defrag)
echo   [3] Voltar ao Menu Principal
echo.
set /p sub_limp="Escolha uma opcao (1-3): "
if "%sub_limp%"=="1" goto LIMPEZA
if "%sub_limp%"=="2" goto DISCOS
if "%sub_limp%"=="3" goto MENU
goto MENU_LIMPEZA

:MENU_REDE
cls
echo =========================================================================================
echo   CATEGORIA: REDE E COMPARTILHAMENTO
echo =========================================================================================
echo.
echo   [1] Otimizacao de Rede e Limpeza de Cache DNS (Flush DNS)
echo   [2] Correcao de Compartilhamento (Impressoras 709/11b e Arquivos)
echo   [3] Voltar ao Menu Principal
echo.
set /p sub_rede="Escolha uma opcao (1-3): "
if "%sub_rede%"=="1" goto REDE
if "%sub_rede%"=="2" goto COMPARTILHAMENTO
if "%sub_rede%"=="3" goto MENU
goto MENU_REDE

:MENU_SISTEMA
cls
echo =========================================================================================
echo   CATEGORIA: SISTEMA, REPAROS E ATUALIZACOES
echo =========================================================================================
echo.
echo   [1] Diagnostico, Verificacao e Reparo de Arquivos (DISM e SFC)
echo   [2] Atualizacao de Programas em Lote (Winget Upgrade)
echo   [3] Voltar ao Menu Principal
echo.
set /p sub_sist="Escolha uma opcao (1-3): "
if "%sub_sist%"=="1" goto REPARO
if "%sub_sist%"=="2" goto ATUALIZACAO
if "%sub_sist%"=="3" goto MENU
goto MENU_SISTEMA


:: =========================================================================================
:: FLUXO DE EXECUCAO AUTOMATICA
:: =========================================================================================

:COMPLETA
cls
echo =========================================================================================
echo   INICIANDO OTIMIZACAO COMPLETA - OTIMIZADOR WINDOWS 11
echo =========================================================================================
echo.
echo   Este processo executara todas as etapas consecutivamente de forma automatica.
echo   Por favor, aguarde a finalizacao de todos os modulos...
echo.
timeout /t 3 >nul
goto L_PROCESSO

:REDE_VOLTA
goto R_PROCESSO

:REPARO_VOLTA
goto REP_PROCESSO

:COMPARTILHAMENTO_VOLTA
goto C_PROCESSO

:DISCOS_VOLTA
goto D_PROCESSO

:ATUALIZACAO_VOLTA
goto A_PROCESSO


:: =========================================================================================
:: MODULOS DE EXECUCAO
:: =========================================================================================

:LIMPEZA
cls
echo =========================================================================================
echo   PROCESSANDO: LIMPEZA DE ARQUIVOS TEMPORARIOS E CACHE
echo =========================================================================================
:L_PROCESSO
echo [+] Excluindo arquivos temporarios de usuario (Temp)...
del /f /s /q "%userprofile%\AppData\Local\Temp\*.*" >nul 2>&1
rd /s /q "%userprofile%\AppData\Local\Temp" >nul 2>&1
mkdir "%userprofile%\AppData\Local\Temp" >nul 2>&1

echo [+] Excluindo arquivos temporarios do sistema (Windows Temp)...
del /f /s /q "%systemroot%\Temp\*.*" >nul 2>&1
rd /s /q "%systemroot%\Temp" >nul 2>&1
mkdir "%systemroot%\Temp" >nul 2>&1

echo [+] Limpando a pasta de otimizacao de inicializacao Prefetch...
del /f /s /q "%systemroot%\Prefetch\*.*" >nul 2>&1

echo [+] Interrompendo servicos do Windows Update temporariamente para limpar cache...
net stop wuauserv >nul 2>&1
net stop bits >nul 2>&1
echo [+] Limpando cache de downloads do Windows Update...
del /f /s /q "%systemroot%\SoftwareDistribution\Download\*.*" >nul 2>&1
net start wuauserv >nul 2>&1
net start bits >nul 2>&1

echo [+] Eliminando arquivos de log antigos acumulados (*.log)...
del /f /s /q %systemdrive%\*.log >nul 2>&1

echo [OK] Modulo de Limpeza concluido com sucesso!
if "%opcao%"=="1" (
    echo -----------------------------------------------------------------------------------------
    goto REDE_VOLTA
)
echo.
pause
goto MENU


:REDE
cls
echo =========================================================================================
echo   PROCESSANDO: OTIMIZACAO DE REDE E FLUSH DE DNS
echo =========================================================================================
:R_PROCESSO
echo [+] Liberando e limpando o cache de resolucao DNS do Windows...
ipconfig /flushdns >nul 2>&1
echo [+] Renovando o registro do DNS...
ipconfig /registerdns >nul 2>&1
echo [+] Redefinindo o catalogo Winsock (Protocolos de Rede)...
netsh winsock reset >nul 2>&1
echo [+] Redefinindo completamente a pilha TCP/IP...
netsh int ip reset >nul 2>&1
echo [OK] Rede e parametros de conexao otimizados!
if "%opcao%"=="1" (
    echo -----------------------------------------------------------------------------------------
    goto REPARO_VOLTA
)
echo.
pause
goto MENU


:REPARO
cls
echo =========================================================================================
echo   PROCESSANDO: VERIFICACAO DE INTEGRIDADE E REPARO DE ARQUIVOS
echo =========================================================================================
:REP_PROCESSO
echo [+] Executando DISM para reparar a imagem base do Windows...
echo     (Isso pode levar varios minutos, o processo parece travar mas esta rodando. Aguarde.)
dism /online /cleanup-image /restorehealth
echo.
echo [+] Executando SFC para corrigir os arquivos do sistema usando a imagem reparada...
sfc /scannow
echo.
echo [+] Limpando componentes antigos de atualizacao para liberar espaco...
dism /online /cleanup-image /startcomponentcleanup /quiet
echo.
echo [OK] Verificacao de integridade e reparos concluidos!
if "%opcao%"=="1" (
    echo -----------------------------------------------------------------------------------------
    goto COMPARTILHAMENTO_VOLTA
)
echo.
pause
goto MENU


:COMPARTILHAMENTO
cls
echo =========================================================================================
echo   PROCESSANDO: CORRECAO DE COMPARTILHAMENTO (IMPRESSORAS E ARQUIVOS)
echo =========================================================================================
:C_PROCESSO
echo [+] Aplicando bypass no registro para o Erro 0x0000011b (PrintNightmare)...
reg add "HKEY_LOCAL_MACHINE\System\CurrentControlSet\Control\Print" /v RpcAuthnLevelPrivacyEnabled /t REG_DWORD /d 0 /f >nul 2>&1

echo [+] Aplicando regras RPC para contornar o Erro 0x00000709...
reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows NT\Printers\RPC" /v RpcUseNamedPipeProtocol /t REG_DWORD /d 1 /f >nul 2>&1
reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows NT\Printers\RPC" /v RpcProtocols /t REG_DWORD /d 7 /f >nul 2>&1

echo [+] Reiniciando o servico de Spooler de Impressao para aplicar os registros...
net stop spooler >nul 2>&1
net start spooler >nul 2>&1

echo [+] Habilitando Descoberta de Rede e Compartilhamento no Firewall do Windows...
netsh advfirewall firewall set rule group="Descoberta de rede" new enable=Yes >nul 2>&1
netsh advfirewall firewall set rule group="Compartilhamento de arquivo e impressora" new enable=Yes >nul 2>&1

echo [+] Forcando inicializacao automatica de servicos de rede essenciais (FDResPub/Lanman)...
sc config fdPHost start= auto >nul 2>&1
sc config FDResPub start= auto >nul 2>&1
sc config lanmanworkstation start= auto >nul 2>&1
sc config lanmanserver start= auto >nul 2>&1
net start fdPHost >nul 2>&1
net start FDResPub >nul 2>&1

echo [OK] Regras de rede, firewall e spooler de impressao corrigidas!
if "%opcao%"=="1" (
    echo -----------------------------------------------------------------------------------------
    goto DISCOS_VOLTA
)
echo.
pause
goto MENU


:DISCOS
cls
echo =========================================================================================
echo   PROCESSANDO: OTIMIZACAO DE DISCOS E AJUSTE DE ENERGIA
echo =========================================================================================
:D_PROCESSO
echo [+] Configurando o Plano de Energia para "Alto Desempenho"...
powercfg /setactive 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c >nul 2>&1

echo [+] Otimizando e aplicando comando TRIM/Defrag no disco principal (C:)...
defrag C: /O /U
echo [OK] Otimizacao de armazenamento e energia aplicados!

if "%opcao%"=="1" (
    echo -----------------------------------------------------------------------------------------
    goto ATUALIZACAO_VOLTA
)
echo.
pause
goto MENU


:ATUALIZACAO
cls
echo =========================================================================================
echo   PROCESSANDO: ATUALIZACAO DE PROGRAMAS (WINGET)
echo =========================================================================================
:A_PROCESSO
echo [+] Buscando e instalando atualizacoes de programas via repositorios oficiais...
echo     (Isso pode demorar dependendo da quantidade de atualizacoes disponiveis)
winget upgrade --all --include-unknown --accept-package-agreements --accept-source-agreements
echo.
echo [OK] Programas atualizados com sucesso!

if "%opcao%"=="1" (
    echo.
    echo =========================================================================================
    echo   OTIMIZACAO COMPLETA EXECUTADA E CONCLUIDA!
    echo   Criado por Johnny_Gedulin
    echo   Recomendamos reiniciar o sistema para que todas as alteracoes entrem em vigor.
    echo =========================================================================================
    echo.
    pause
    goto MENU
)
echo.
pause
goto MENU